<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog_model extends CI_Model {
		public function __construct(){
			$this->load->database();
			$this->load->library('pagination');
		}

	public function save_comment($data,$id)
	{
		

		$this->db->insert('comment_t',$data,$id);
		return $this->db->affected_rows();
	}
	public function view_comment($id)
	{
		 $this->db->select('*');
		 $this->db->where('id',$id);
		$result= $this->db->get('comment_t');
		return $result->result_array();
	}

	public function getAllGroups()
	{
		$query=$this->db->query('SELECT name FROM category_t');
		return $query->result_array();
	}
		//upload images
	public function insert_image($image)
 {
  // assign the data to an array
 	date_default_timezone_set('Asia/Manila'); # add your city to set local time zone
	$now = date('Y-m-d H:i:s');
  $data = array(
   
   'name' => $this->input->post('blog_name'),
   'category' => $this->input->post('category'),
   'description' => $this->input->post('description'),
   'image' => $image,
   'date'=> $now
  );
  //insert image to the database
  $this->db->insert('entries_t', $data);
 }
 //get images from database
  public function get_images()
 {
  $this->db->select('*');
  $this->db->order_by('id','desc');
  $query = $this->db->get('entries_t');
  return $query->result_array();
 }

public function getcat($name)
	{
		$this->db->select('*');
		$this->db->where('category',$name);
		$this->db->order_by('id','desc');
		$query=$this->db->get('entries_t');

		return $query->result_array();
	}
	public function indi_blog($id)
	{
		$this->db->select('*');
		$this->db->where('id',$id);
		$query=$this->db->get('entries_t');
		return $query->result_array();
	}

	public function save_message($todo)
	{
		$this->db->insert('message_t',$todo);
		return $this->db->affected_rows();	
	}
	public function view_message()
	{
		$this->db->select('*');
		$query=$this->db->get('message_t');
		return $query->result_array();
	}
	public function latest()
	{
		$this->db->select('*');
		$this->db->order_by('id','desc');
		$query=$this->db->get('entries_t');
		return $query->result_array();
	}
	public function related($id,$cat)
	{
		$this->db->select('*');
		$this->db->where('id !=', $id);
		$this->db->where('category',$cat);
		$this->db->order_by('id','desc');
		$query=$this->db->get('entries_t');
		return $query->result_array();
	}
	public function delete_b($id)
	{
		$this->db->where('id',$id);
		$result=$this->db->delete('comment_t');
		$this->db->where('id',$id);
		$query=$this->db->delete('entries_t');
		if ($this->db->affected_rows()>0) {
			return $result;
			return $query;
		}
	}

	
		
		
 }


