
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {


public function index()
	{
		$name=$this->input->get('name');
		$this->load->model('blog_model');
		$data['groups']=$this->blog_model->getAllGroups();
		$data['images']=$this->blog_model->getcat($name);
		$this->load->view('templates/header');
		$this->load->view('templates/nav');
		$this->load->view('blogs/Blog',$data);
		$this->load->view('templates/footer');
	}
}