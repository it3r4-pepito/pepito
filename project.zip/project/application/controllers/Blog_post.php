<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog_post extends CI_Controller {
	

	public function index()
	{
		$id=$this->input->get('id');
		$cat=$this->input->get('category');
				$this->load->model('blog_model');
		
		$data = array(
			'todoss' => $this->blog_model->view_comment($id),
			'todos' =>$this->blog_model->indi_blog($id),
			'groups' => $this->blog_model->getAllGroups(),
			'latest' => $this->blog_model->latest(),
			'related' => $this->blog_model->related($id,$cat),
			 );

		
		$this->load->view('templates/header');
		$this->load->view('templates/nav');
		$this->load->view('blogs/blog_post',$data);
		$this->load->view('templates/footer');
		
	}
	public function comment(){
		$id=$this->input->get('id');
		$cat=$this->input->get('category');
	if($this->input->server('REQUEST_METHOD') === 'POST'){
		$name=$this->input->post('author');
		$email=$this->input->post('email');
		$comment=$this->input->post('comment');
		date_default_timezone_set('Asia/Manila'); # add your city to set local time zone
	$now = date('Y-m-d H:i:s');
		$data = array(
		'comment_name' => $name,
		'comment_email' => $email,
		'comment_comment' => $comment ,
		'comment_date' => $now,
		'id' =>$id
		);

		$this->load->model('blog_model');
		$result=$this->blog_model->save_comment($data,$id);

		if($result > 0){
			header('location:'.base_url('blog_post') .'?id='. $id. '&category='.$cat);
		}
	}
	
	}
}