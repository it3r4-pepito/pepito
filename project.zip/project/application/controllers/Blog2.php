<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog2 extends CI_Controller {

	public function index()
	{

		$this->load->view('templates/header');
		$this->load->view('templates/nav');
		$this->load->view('blogs/Blog2');
		$this->load->view('templates/footer');
	}
}
