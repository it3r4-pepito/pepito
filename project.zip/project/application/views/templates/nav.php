	<body class="is-preload">

		<!-- Header -->
			<header id="header">
				<nav>
					<ul>
						<li class="menu_item"><a href="Home">Home</a></li>
						<li class="menu_item"><a href="Blog">NBA Blog Post</a></li>
						  <li class="menu_item"><a href="Login">Login</a></li>
						<li class="menu_item"><a href="Contact">Contact Us</a></li>
					</ul>
				</nav>
			</header>