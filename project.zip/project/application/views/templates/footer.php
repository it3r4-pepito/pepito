		<!-- Footer -->
			<footer id="footer">

				<!-- About US-->
				<div class="col-lg-3  col-md-6 col-sm-6">
                        <div class="single-footer-widget">
                            <h6 class="footer_title">About Us</h6>
                            <p>UNDER CONSTRUCT</p>
                        </div>
                    </div>


					

				<!-- Menu -->
					<ul class="menu">
						<li>&copy; LONGNECK PRODUCTION</li><li>Design by: 3r4 Devils</li>
					</ul>

			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.poptrox.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>
