<link href="assets/css/modified.css" rel="stylesheet">


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <title>SpicyX | Blog Archive</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">

    <!-- Font awesome -->
    <link href="assets/css/font-awesome.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="<?php echo  base_url("assets/css/bootstrap.min.css"); ?>" rel="stylesheet">   
    <!-- Slick slider -->
    <link rel="stylesheet" type="text/css" href="assets/css/slick.css">    
    <!-- Date Picker -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-datepicker.css">    
    <!-- Fancybox slider -->
    <link rel="stylesheet" href="assets/css/jquery.fancybox.css" type="text/css" media="screen" /> 
    <!-- Theme color -->
    <link id="switcher" href="assets/css/theme-color/default-theme.css" rel="stylesheet">     

    <!-- Main style sheet -->
    <link href="style.css" rel="stylesheet">    

   
    <!-- Google Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Tangerine' rel='stylesheet' type='text/css'>        
    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Prata' rel='stylesheet' type='text/css'>
    

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body>  
  



  


  
  <!-- Start Blog -->
  <section id="mu-blog">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="mu-blog-area">
            <div class="row">
              <div class="col-lg-8 col-md-9 col-sm-9 container blogpost">
                <div class="mu-blog-content">
                  <!-- Start Single blog item -->
                  <?php foreach($todos as $todo): ;?>
                  <article class="mu-news-single">
                    <h3><a href="#"><?php echo $todo['name'];?></a></h3>
                    <figure class="mu-news-img">
                      <a href="#"><img class="responsive1" src="<?php echo base_url() ?>assets/images/<?php echo $todo['image'] ?>" alt="img"></a>                      
                    </figure>
                    <div class="" align="center">                      
                      
                      <p><?php echo $todo['description'];?></p>
                 </div>
               <?php endforeach;?>

                 <!-- Start related news -->
                <div class="row">
                  <div class="col-md-12">
                    <div class="mu-blog-related-post">
                      <div class="mu-title">                        
                        <h2 align="center">Related Blogs</h2>
                        <i class="fa fa-spoon"></i>              
                        <span class="mu-title-bar"></span>
                      </div>
                      <div align="center" class="mu-blog-related-post-area">
                        <div class="row">
                          <?php $i=0?>
                          <?php foreach($related as $relate):; ?>
                           <?php if($i == 2) break;?>
                          <div class="col-md-6 col-sm-6">
                            <article class="mu-news-single">
                              <h3><a href="#"><?php echo $relate['name'];?></a></h3>
                              <figure class="mu-news-img">
                                <a href="#"><img class="responsive-single"  src="<?php echo base_url()?>assets/img/food/<?php echo $relate['image'];?>"></a>                      
                              </figure>
                              <div class="mu-news-single-content">                      
                                
                                <p><?php echo substr($relate['description'],0,50);?>...</p>
                                <div class="mu-news-single-bottom">
                                  <a class="btn btn-secondary" href="<?php echo base_url("blog_post?id=".$relate["id"]."&category=".$relate["category"]);?>">Read More</a>
                                </div>
                              </div>                   
                            </article>
                          </div>
                          <?php $i++?>
                        <?php endforeach;?>
                          
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- End related news -->
                </div>


                <!-- Start Blog comments thread -->
                <div class="row">
                  <div class="col-md-12 " >
                    <div class="mu-comments-area ">
                      <h3 class="comments h333"><strong>Comments</strong></h3>
                      <div class="comments ">
                        <ul class="commentlist">
                          <?php foreach($todoss as $to): ;?>
                          
                            <div class="media jumbotron">
                              <div class="media-left ">    
                                <img style="height: 110px; width: 110px;" class="media-object news-img " src="<?php echo base_url() ?>assets/img/name/<?php echo substr($to['comment_name'], 0,1) ?>.jpg" alt="img">
                              </div>
                              <div class="media-body ">
                               <h4 class="author-name "><?php echo $to['comment_name'];?></h4>
                               <span class="comments-date"> Posted on <?php echo $to['comment_date'];?></span>
                               <p><?php echo $to['comment_comment'];?></p>
                               <a href="#" class="reply-btn">Reply</a>
                              </div>
                            </div>
                          <?php endforeach; ?>
                        
                          
                        
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Start Blog comments thread -->
                <!-- Start comments box -->
                <div class="row">
                  <div class="col-md-12">
                    <div id="respond">
                      <h3 class="reply-title commenth3">Leave a Comment</h3>
                      <form id="commentform" method="POST" action="<?php echo base_url("Blog_post/comment?id=".$this->input->get("id")."&category=".$this->input->get("category"));?>">
                        <p class="comment-notes commenth3">
                          Your email address will not be published. Required fields are marked <span class="required">*</span>
                        </p>

                        <p class=" commenth3"><label for="author">Name <span class="required">*</span></label></p>
                        <p class="comment-form-author commenth3">
                          
                          <input type="text" name="author" value="" size="30" required="required">
                        </p>

                        <p class=" commenth3"> <label for="email">Email <span class="required ">*</span></label></p>
                        <p class="comment-form-email commenth3">
                         
                          <input type="email" name="email" value="" aria-required="true" required="required">
                        </p>
                        

                        <p class=" commenth3"> <label for="comment commenth3">Comment</label></p>
                        <p class="comment-form-comment commenth3">
                         
                          <textarea name="comment" cols="45" rows="8" aria-required="true" required="required"></textarea>
                        </p>
                        
                        <p class="form-submit commenth3">
                          <input type="submit" name="submit" class="btn" value="Post Comment">
                        </p>        
                      </form>
                    </div>
                  </div>
                </div>
                <!-- End comments box -->
             





        
                <div class="row">
                  <div class="col-md-12" style="margin-top: 50px; ">
                    <ul class="pagination">
                      <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                      <li class="page-item"><a class="page-link" href="#">1</a></li>
                      <li class="page-item"><a class="page-link" href="#">2</a></li>
                      <li class="page-item"><a class="page-link" href="#">3</a></li>
                      <li class="page-item"><a class="page-link" href="#">Next</a></li>
                    </ul>
                  </div>
                </div>
              </div>
             <!-- Start Blog Sidebar -->
              <div class="col-md-3 col-sm-3 container contac" >             
                <aside class="">
                  <!-- Blog Sidebar Single -->
                  <div class="jumbotron sidemodal" style="margin-top: 75px;">
                    <h3  >Categories</h3>
                    <ul class="mu-catg-nav">
                      <?php  foreach($groups as $tod): ;?>
                      <li><a href="<?php echo base_url('category');?>?name=<?php echo $tod['name']; ?>"><?php echo $tod['name'];?></a></li>
                      <?php endforeach;?>
                    </ul>
                  </div>
                  <!-- End Blog Sidebar Single -->
                  <!-- Blog Sidebar Single -->
                  <div class="sidemodal jumbotron">
                    <h3>Latest Blog</h3>
                    <ul class="mu-recent-news-nav">
                      <?php foreach($latest as $late):;?>
                      <li><a href="<?php echo base_url('blog_post?id='.$late['id'].'&category='.$late['category']);?>"><?php echo $late['name'];?></a></li>
                    <?php endforeach;?>
                    </ul>
                  </div>
                  <!-- End Blog Sidebar Single -->
                  
                  <!-- Blog Sidebar Single -->
                  <div class="">                    
                    <a href="#" class="mu-sidebar-add">
                      <img src="assets/img/food/IMG_5947.jpg" alt="img" >
                    </a>
                  </div>
                  <!-- End Blog Sidebar Single -->
                </aside>
              </div>
              <!-- End Blog Sidebar -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End Blog -->
  
 
