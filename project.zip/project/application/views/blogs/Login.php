			
<section id="intro1">
			 <div id="main-wrapper">
        <center><h2>Login Form</h2>
        <img src="images/nba-logo.png" class="logo"/>
        </center>

    
    <form class="myform" action="login.php" method="post">
        <label><b>Username:</b></label><br>
        <input type="text" class="inputvalues" placeholder="Type your username" ><br>

        <label><b>Password:</b></label><br>
        <input type="password" class="inputvalues" placeholder="Type your password" ><br>
        <input type="submit" id="login_btn" value="Login" ><br>
        <a href="Register"><input type="button" id="register_btn" value="Register" ><br>


    </form>
    </div>
</section>
