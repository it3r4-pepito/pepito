
		<!-- Intro -->
			<section id="intro1" class="main style1 dark fullscreen">
				<div class="content">
					<header>
						<img src="images/nba-logo.png" title="UNDER CONSTRUCT " alt="" /></a>

					</header>
					
					
				</div>
			</section>



		<!-- Intro 2 -->
			<section id="intro2" class="main style2 right dark fullscreen" >
				<div class="content box style2">
					<a href="Allstar"><h2>ALL STAR</h2></a>
					<p>NBA All-Star 2018-19 East & West Line Up</p>
				</div>
			
			</section>

		<!-- Intro 3 -->
			<section id="intro3" class="main style2 left dark fullscreen">
				<div class="content box style2">
					<a href="#"><h2>2018-19 NBA Ranking</h2></a>
					<p>NBA Ranking</p>
				</div>
				
			</section>

			<section id="intro4" class="main style2 right dark fullscreen" >
				<div class="content box style2">
					<a href="#"><h2>NBA Teams 2018-19 Season</h2></a>
					<p>Team Starting Line UP</p>
				</div>
			</section>

		<!--Comment Section-->
		<section>
			<div class="comments-area">
                            <h4>05 Comments</h4>
                            <div class="comment-list">
                                <div class="single-comment justify-content-between d-flex">
                                    <div class="user justify-content-between d-flex">
                                        <div class="thumb">
                                            <img src="images/c1.jpg" alt="">
                                        </div>
                                        <div class="desc">
                                            <h5><a href="#">Maria Ozawa</a></h5>
                                            <p class="date">December 4, 2017 at 3:12 pm </p>
                                            <p class="comment">
                                                LEBRON JAMES! YOUR THE ONE!! MY NIGGA!!!!!
                                            </p>
                                        </div>
                                    </div>
                                     <div class="reply-btn">
                                           <a href="" class="btn-reply text-uppercase">reply</a> 
                                    </div>
                                </div>
                            </div>	
                            <div class="comment-list left-padding">
                                <div class="single-comment justify-content-between d-flex">
                                    <div class="user justify-content-between d-flex">
                                        <div class="thumb">
                                            <img src="images/c2.jpg" alt="">
                                        </div>
                                        <div class="desc">
                                            <h5><a href="#">Daddy Louie</a></h5>
                                            <p class="date">March 3, 2019 at 3:12 pm </p>
                                            <p class="comment">
                                                I love this NBA BLOG PAGE!
                                            </p>
                                        </div>
                                    </div>
                                     <div class="reply-btn">
                                           <a href="" class="btn-reply text-uppercase">reply</a> 
                                    </div>
                                </div>
                            </div>	
                            <div class="comment-list left-padding">
                                <div class="single-comment justify-content-between d-flex">
                                    <div class="user justify-content-between d-flex">
                                        <div class="thumb">
                                            <img src="images/c3.jpg" alt="">
                                        </div>
                                        <div class="desc">
                                            <h5><a href="#">Emily Blunt</a></h5>
                                            <p class="date">March 3, 2019 at 3:12 pm </p>
                                            <p class="comment">
                                                LAKERS FAN!! HERE!! WOOHOOOOOOOOOOO!!! I LOVE YOU L.A
                                            </p>
                                        </div>
                                    </div>
                                     <div class="reply-btn">
                                           <a href="" class="btn-reply text-uppercase">reply</a> 
                                    </div>
                                </div>
                            </div>	
                            <div class="comment-list">
                                <div class="single-comment justify-content-between d-flex">
                                    <div class="user justify-content-between d-flex">
                                        <div class="thumb">
                                            <img src="images/c4.jpg" alt="">
                                        </div>
                                        <div class="desc">
                                            <h5><a href="#">2n1</a></h5>
                                            <p class="date">March 3, 2019 at 3:12 pm </p>
                                            <p class="comment">
                                                NO ONE CAN DEFAT LEBRON THE REAL GOAT!!!!
                                            </p>
                                        </div>
                                    </div>
                                     <div class="reply-btn">
                                           <a href="" class="btn-reply text-uppercase">reply</a> 
                                    </div>
                                </div>
                            </div>	
                            <div class="comment-list">
                                <div class="single-comment justify-content-between d-flex">
                                    <div class="user justify-content-between d-flex">
                                        <div class="thumb">
                                            <img src="images/c5.jpg" alt="">
                                        </div>
                                        <div class="desc">
                                            <h5><a href="#">Mang Kanor</a></h5>
                                            <p class="date">March 3, 2019 at 3:12 pm </p>
                                            <p class="comment">
                                                GIANIS!!! MVP! MVP! MVP! MVP! MVP!
                                            </p>
                                        </div>
                                    </div>
                                     <div class="reply-btn">
                                           <a href="" class="btn-reply text-uppercase">reply</a> 
                                    </div>
                                </div>
                            </div>	                                             				
                        </div>
				</section>




