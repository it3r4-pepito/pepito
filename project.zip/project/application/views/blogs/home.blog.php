<link href="assets/css/modified.css" rel="stylesheet">

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <title>SpicyX | Blog </title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">

    <!-- Font awesome -->
    <link href="assets/css/font-awesome.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">   
    <!-- Slick slider -->
    <link rel="stylesheet" type="text/css" href="assets/css/slick.css">    
    <!-- Date Picker -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-datepicker.css">    
    <!-- Fancybox slider -->
    <link rel="stylesheet" href="assets/css/jquery.fancybox.css" type="text/css" media="screen" /> 
    <!-- Theme color -->
    <link id="switcher" href="assets/css/theme-color/default-theme.css" rel="stylesheet">     

    <!-- Main style sheet -->
    <link href="/assets/style.css" rel="stylesheet">    

   
    <!-- Google Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Tangerine' rel='stylesheet' type='text/css'>        
    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Prata' rel='stylesheet' type='text/css'>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body>  
  


  <!-- Start Blog -->
  <section>
    <div class="container-fluid " style="margin-top: 100px;">
      <div class="row">
        <div class="col-md-12">
            <div class="row">
              <div class="col-lg-8 col-md-9 col-sm-9 container blog123">
                <h1 class="heading" ><?php echo $this->input->get('name');?></h1>
                <div class="mu-blog-content">
                  <?php foreach($images as $todo): ;?>
                  <!-- Start Single blog item -->
                  <article class="mu-news-single">
                    <h3><a href="#"><?php echo $todo['name'];?></a></h3>
                    <figure class="mu-news-img">
                      <a href="<?php echo base_url("blog_post?id=".$todo["id"]."&category=".$todo["category"]);?>"><img class="responsive1" src="<?php echo base_url() ?>assets/images/<?php echo $todo['image'] ?>" alt="img"></a>                      
                    </figure>
                    <div class="" align="center">                      
                      
                      <p><?php echo substr($todo['description'], 0,50);?>...</p>
                      <div align= "center" class="">
                        <a  align="center" href="<?php echo base_url("blog_post?id=".$todo["id"]."&category=".$todo["category"]);?>" class="btn btn-secondary align-items-center">Read More</a>
                      </div>
                    </div>                   
                  </article>
                <?php endforeach;?>
                  <!-- End Single blog item -->
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <ul class="pagination">
                      <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                      <li class="page-item"><a class="page-link" href="#">1</a></li>
                      <li class="page-item"><a class="page-link" href="#">2</a></li>
                      <li class="page-item"><a class="page-link" href="#">3</a></li>
                      <li class="page-item"><a class="page-link" href="#">Next</a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <!-- Start Blog Sidebar -->
              <div class="col-lg-3 col-md-3 col-sm-3 container blog12" >             
                <aside class="responsive">
                  <!-- Blog Sidebar Single -->
                  <div class="jumbotron" style="margin-top: 85px;">
                    <h3  >Categories</h3>
                    <ul class="mu-catg-nav">
                      <?php foreach($groups as $todo): ;?>
                      <li><a href="<?php echo base_url('category');?>?name=<?php echo $todo['name']; ?>"><?php echo $todo['name'];?></a></li>
                      <?php endforeach;?>
                    </ul>
                  </div>
                  <!-- End Blog Sidebar Single -->
                  <!-- Blog Sidebar Single -->
                  
                  <div class="sidemodal jumbotron">
                    <h3>Latest Blog</h3>
                    <ul class="mu-recent-news-nav">
                      <?php foreach($images as $todo): ;?>
                      <li><a href="<?php echo base_url("blog_post?id=".$todo['id']."&category=".$todo['category']);?>"><?php echo $todo['name'];?></a></li>
                      <?php endforeach;?>
                    </ul>
                  </div>
                
                  <!-- End Blog Sidebar Single -->
                  
                  <!-- Blog Sidebar Single -->
                  <div class="mu-blog-sidebar-single">                    
                    <a href="#" class="mu-sidebar-add">
                      <img src="assets/img/food/IMG_5947.jpg" alt="img">
                    </a>
                  </div>
                  <!-- End Blog Sidebar Single -->
                </aside>
              </div>
              <!-- End Blog Sidebar -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End Blog -->
  
  
 
  
    