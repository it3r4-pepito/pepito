        
        <!--Blog Area-->
        <section id="intro1" class="blog_area p_120">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="blog_left_sidebar">
                            <article class="blog_style1">
                                <div class="blog_img">
                                   <img class="img-fluid" src="images/IntroNBA.jpg" alt="">
                                </div>
                                <div class="blog_text">
                                    <div class="blog_text_inner">
                                        <div class="cat">
                                            <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March 3, 2019</a>
                                            <a href="#"><i class="fa fa-comments-o" aria-hidden="true"></i> 05</a>
                                        </div>
                                        <a href="#"><h4>NBA Teams 2018-19 Season</h4></a>
                                        <p>UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT
                                        UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT</p>
                                        <a class="blog_btn" href="#">Read More</a>
                                    </div>
                                </div>
                            </article>
                            <div class="row">
                                <div class="col-md-6">
                                    <article class="blog_style1 small">
                                        <div class="blog_img">
                                            <img class="img-fluid" src="images/Sample.jpg" alt="">
                                        </div>
                                        <div class="blog_text">
                                            <div class="blog_text_inner">
                                                <div class="cat">
                                                    <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March 3, 2019</a>
                                                    <a href="#"><i class="fa fa-comments-o" aria-hidden="true"></i> 05</a>
                                                </div>
                                                <a href="single-blog.html"><h4>NBA Teams 2018-19 East</h4></a>
                                                <p>UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT
                                                UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT</p>
                                                <a class="blog_btn" href="#">Read More</a>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                                <div class="col-md-6">
                                    <article class="blog_style1 small">
                                        <div class="blog_img">
                                            <img class="img-fluid" src="images/Sample - Copy.jpg" alt="">
                                        </div>
                                        <div class="blog_text">
                                            <div class="blog_text_inner">
                                                <div class="cat">
                                                    <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i> March 3, 2019</a>
                                                    <a href="#"><i class="fa fa-comments-o" aria-hidden="true"></i> 05</a>
                                                </div>
                                                <a href="single-blog.html"><h4>NBA Teams 2018-19 West</h4></a>
                                                <p>UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT 
                                                UNDER CONSTRUCT  UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT UNDER CONSTRUCT</p>
                                                <a class="blog_btn" href="#">Read More</a>  
                                            </div>
                                        </div>
                                    </article>
                                </div>
                            </div>
                                <div class="comment-form">
                                <h4>Leave a Comment</h4>
                                <form>
                                    <div class="form-group form-inline">
                                      <div class="form-group col-lg-6 col-md-6 name">
                                        <input type="text" class="form-control" id="name" placeholder="Enter Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Name'">
                                      </div>
                                      <div class="form-group col-lg-6 col-md-6 email">
                                        <input type="email" class="form-control" id="email" placeholder="Enter email address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter email address'">
                                      </div>                                        
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="subject" placeholder="Subject" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Subject'">
                                    </div>
                                    <div class="form-group">
                                        <textarea class="form-control mb-10" rows="5" name="message" placeholder="Messege" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Messege'" required=""></textarea>
                                    </div>
                                    <a href="#" class="primary-btn submit_btn">Post Comment</a> 
                                </form>
                            </div>
                            <nav class="blog-pagination justify-content-center d-flex">
                                <ul class="pagination">
                                    <li class="page-item">
                                        <a href="Blog2" class="page-link" aria-label="Previous">
                                            <span aria-hidden="true">
                                                <span class="lnr lnr-chevron-left"></span>
                                            </span>
                                        </a>
                                    </li>
                                    <li class="page-item"><a href="blog" class="page-link">01</a></li>
                                    <li class="page-item"><a href="Blog2" class="page-link">02</a></li>
                                    <li class="page-item  active"><a href="Blog3" class="page-link">03</a></li>
                                    <li class="page-item">
                                        <a href="Blog1" class="page-link" aria-label="Next">
                                            <span aria-hidden="true">
                                                <span class="lnr lnr-chevron-right"></span>
                                            </span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="blog_right_sidebar">
                            <aside class="single_sidebar_widget search_widget">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search Posts">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button"><i class="lnr lnr-magnifier"></i></button>
                                    </span>
                                </div><!-- /input-group -->
                                <div class="br"></div>
                            </aside>
                            <aside class="single_sidebar_widget author_widget">
                                <img class="author_img img-fluid" src="images/2016-1203-LeBron-James-SOTY-shoot-SI648_TK1_00204.jpg" alt="">
                                <h4>Lebron James</h4>
                                <p>NBA All Star Player in L.A Lakers Forward</p>
                                <p>Under Construct</p>
                                <div class="social_icon">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                </div>
                                <div class="br"></div>
                            </aside>
                            <aside class="single_sidebar_widget popular_post_widget">
                                <h3 class="widget_title">Popular Posts</h3>
                                <div class="media post_item">
                                    <img src="images/S.jpg" alt="post">
                                    <div class="media-body">
                                        <a href=""><h3>UNDER CONSTRUCT</h3></a>
                                        <p>02 Hours ago</p>
                                    </div>
                                </div>
                                <div class="media post_item">
                                    <img src="images/A.jpg" alt="post">
                                    <div class="media-body">
                                        <a href=""><h3>UNDER CONSTRUCT</h3></a>
                                        <p>02 Hours ago</p>
                                    </div>
                                </div>
                                <div class="media post_item">
                                    <img src="images/m.jpg" alt="post">
                                    <div class="media-body">
                                        <a href=""><h3>UNDER CONSTRUCT</h3></a>
                                        <p>03 Hours ago</p>
                                    </div>
                                </div>
                                <div class="media post_item">
                                    <img src="images/P.jpg" alt="post">
                                    <div class="media-body">
                                        <a href=""><h3>UNDER CONSTRUCT</h3></a>
                                        <p>01 Hours ago</p>
                                    </div>
                                </div>
                                 <div class="media post_item">
                                    <img src="images/L.jpg" alt="post">
                                    <div class="media-body">
                                        <a href=""><h3>UNDER CONSTRUCT</h3></a>
                                        <p>01 Hours ago</p>
                                    </div>
                                </div>
                                <div class="media post_item">
                                    <img src="images/E.jpg" alt="post">
                                    <div class="media-body">
                                        <a href=""><h3>UNDER CONSTRUCT</h3></a>
                                        <p>01 Hours ago</p>
                                    </div>
                                </div>
                                <div class="br"></div>
                            </aside>
                            <aside class="single_sidebar_widget post_category_widget">
                                <h4 class="widget_title">Blog Catgories</h4>
                                <ul class="list cat-list">
                                    <li>
                                        <a href="#" class="d-flex justify-content-between">
                                            <p>NBA All-Star 2018-19</p>
                                            <p>3</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" class="d-flex justify-content-between">
                                            <p>2018-19 NBA Ranking</p>
                                            <p>4</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" class="d-flex justify-content-between">
                                            <p>NBA Teams 2018-19</p>
                                            <p>5</p>
                                        </a>
                                    </li>                                           
                                </ul>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
        </section>
