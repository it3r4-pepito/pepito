  <section id="intro6" class="blog_area p_120 single-post-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
       					<div class="main_blog_details">
       						<img class="img-fluid" src="images/AS19-Starters-T1-Jan24.jpg" alt="">
       						<a href="#"><h4>NBA ALLSTAR 2018-19 Season</h4></a>
       						<div class="user_details">
       							<div class="float-right">
       								<div class="media">
       									<div class="media-body">
       										<h5>Jopaw</h5>
       										<p>31 May, 2019 11:21 am</p>
       									</div>
       									<div class="d-flex">
       										<img src="images/41594652_1911959875531080_5505887274467852288_n.jpg" alt="">
       									</div>
       								</div>
       							</div>
       						</div>
                            <blockquote class="blockquote">
       						<p>The 2019 NBA All-Star Game was the 68th edition of the exhibition basketball game played on February 17, 2019. This was the second time that the format was not East/West. The game was held at the Spectrum Center in Charlotte, North Carolina, home of the Charlotte Hornets. Charlotte was announced as host on May 24, 2017. </p>
       						<p>This was the second time that Charlotte hosted the All-Star Game; the first time was in 1991, at the Hornets' previous home arena Charlotte Coliseum. The game was supposed to be played in Charlotte in 2017, but was moved to New Orleans because of controversy surrounding the Public Facilities Privacy & Security Act. The game was televised by TNT for the 17th straight year, and was also simulcast on TBS in some markets.</p>
                            </blockquote>
							<blockquote class="blockquote">
								<p class="mb-0">The two teams were coached from their respective conference. Mike Budenholzer, coach of the Milwaukee Bucks, was named as the head coach for Team Giannis. Michael Malone, coach of the Denver Nuggets, was named as the head coach for Team LeBron. It marks the first time since the 2008 NBA All-Star Game where both coaches did not have a playoff berth during the previous season.</p>
							</blockquote>
                            <blockquote class="blockquote">
							<p>The rosters for the All-Star Game are selected through a voting process. The NBA partnered with Google and removed counting #nbavote hashtags as fan votes. The starters were chosen by the fans, media, and current NBA players. Fans made up 50% of the vote, and NBA players and media each comprised 25% of the vote. The two guards and three frontcourt players who received the highest cumulative vote totals were named the All-Star starters.</p>
							<p> NBA head coaches will vote for the reserves for their respective conferences, none of which can be players from their own team. Each coach selects two guards, three frontcourt players and two wild cards, with each selected player ranked in order of preference within each category. If a multi-position player is to be selected, coaches are encouraged to vote for the player at the position that was "most advantageous for the All-Star team", regardless of where the player was listed on the All-Star ballot or the position he was listed in box scores.</p>
                            </blockquote>
      						<div class="news_d_footer">
      							<a ><i class="lnr lnr lnr-heart"></i>Jopaw and 4 people like this</a>
      							<a class="justify-content-center ml-auto" href="#"><i class="lnr lnr lnr-bubble"></i>Comments</a>
      							<div class="news_socail ml-auto">
									<a href="#"><i class="fa fa-facebook"></i></a>
									<a href="#"><i class="fa fa-twitter"></i></a>
									<a href="#"><i class="fa fa-youtube-play"></i></a>
									<a href="#"><i class="fa fa-pinterest"></i></a>
									<a href="#"><i class="fa fa-rss"></i></a>
								</div>
      						</div>
       					</div>
       				
                        
                        <div class="comment-form">
                            <h4>Leave a Comment</h4>
                            <form>
                                <div class="form-group form-inline">
                                  <div class="form-group col-lg-6 col-md-6 name">
                                    <input type="text" class="form-control" id="name" placeholder="Enter Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Name'">
                                  </div>
                                  <div class="form-group col-lg-6 col-md-6 email">
                                    <input type="email" class="form-control" id="email" placeholder="Enter email address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter email address'">
                                  </div>										
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="subject" placeholder="Subject" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Subject'">
                                </div>
                                <div class="form-group">
                                    <textarea class="form-control mb-10" rows="5" name="message" placeholder="Messege" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Messege'" required=""></textarea>
                                </div>
                                <a href="#" class="primary-btn submit_btn">Post Comment</a>	
                            </form>
                        </div>
        			</div>
                    <div class="col-lg-4">
                        <div class="blog_right_sidebar">
                            <aside class="single_sidebar_widget search_widget">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search Posts">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button"><i class="lnr lnr-magnifier"></i></button>
                                    </span>
                                </div><!-- /input-group -->
                                <div class="br"></div>
                            </aside>
                            <aside class="single_sidebar_widget author_widget">
                                <img class="author_img img-fluid" src="images/2016-1203-LeBron-James-SOTY-shoot-SI648_TK1_00204.jpg" alt="">
                                <h4>Lebron James</h4>
                                <p>NBA All Star Player in L.A Lakers Forward</p>
                                <p>Under Construct</p>
                                <div class="social_icon">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                </div>
                                <div class="br"></div>
                            </aside>
                            <aside class="single_sidebar_widget popular_post_widget">
                                <h3 class="widget_title">Popular Posts</h3>
                                <div class="media post_item">
                                    <img src="images/S.jpg" alt="post">
                                    <div class="media-body">
                                        <a href=""><h3>UNDER CONSTRUCT</h3></a>
                                        <p>02 Hours ago</p>
                                    </div>
                                </div>
                                <div class="media post_item">
                                    <img src="images/A.jpg" alt="post">
                                    <div class="media-body">
                                        <a href=""><h3>UNDER CONSTRUCT</h3></a>
                                        <p>02 Hours ago</p>
                                    </div>
                                </div>
                                <div class="media post_item">
                                    <img src="images/m.jpg" alt="post">
                                    <div class="media-body">
                                        <a href=""><h3>UNDER CONSTRUCT</h3></a>
                                        <p>03 Hours ago</p>
                                    </div>
                                </div>
                                <div class="media post_item">
                                    <img src="images/P.jpg" alt="post">
                                    <div class="media-body">
                                        <a href=""><h3>UNDER CONSTRUCT</h3></a>
                                        <p>01 Hours ago</p>
                                    </div>
                                </div>
                                 <div class="media post_item">
                                    <img src="images/L.jpg" alt="post">
                                    <div class="media-body">
                                        <a href=""><h3>UNDER CONSTRUCT</h3></a>
                                        <p>01 Hours ago</p>
                                    </div>
                                </div>
                                <div class="media post_item">
                                    <img src="images/E.jpg" alt="post">
                                    <div class="media-body">
                                        <a href=""><h3>UNDER CONSTRUCT</h3></a>
                                        <p>01 Hours ago</p>
                                    </div>
                                </div>
                                <div class="br"></div>
                            </aside>
                            <aside class="single_sidebar_widget post_category_widget">
                                <h4 class="widget_title">Blog Catgories</h4>
                                <ul class="list cat-list">
                                    <li>
                                        <a href="#" class="d-flex justify-content-between">
                                            <p>NBA All-Star 2018-19</p>
                                            <p>3</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" class="d-flex justify-content-between">
                                            <p>2018-19 NBA Ranking</p>
                                            <p>4</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" class="d-flex justify-content-between">
                                            <p>NBA Teams 2018-19</p>
                                            <p>5</p>
                                        </a>
                                    </li>                                           
                                </ul>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================Blog Area =================-->