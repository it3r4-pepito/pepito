			
<section id="intro1">

			 <div id="main-wrapper">
		<center><h2>Registration Form</h2>
		<img src="images/nba-logo.png" class="logo"/>
		</center>

	<form class="myform" action="register.php" method="post">
		<label><b>Username:</b></label><br>
			<input name="username" type="text" class="inputvalues" placeholder="Type Your Username"  required/><br>
		<label><b>Password:</b></label><br>
			<input name="password" type="text" class="inputvalues" placeholder="Your Password" required/><br>
		<label><b>Confirm Password:</b></label><br>
			<input name="cpass" type="password" class="inputvalues" placeholder="Confirm Password" required/><br>
				<a href="Login"></a><input name="submit_btn" type="submit" id="signup_btn" value="Sign Up" ><br>
				<a href="Login"><input type="button" id="back_btn" value="Back" ></a><br>
	</form>

	<?php 
		if(isset($_POST['submit_btn']))
		{
			//echo '<script type="text/javascript"> alert("Sign up button clicked") </script>';

			$username = $_POST['username'];
			$password = $_POST['password'];
			$cpass = $_POST['cpass'];

			if($password==$cpass)
			{
				$query=	"select * from user WHERE username='$username'";
				$query_run = mysqli_query($conn,$query);

				if(mysqli_num_rows($query_run)>0)
				{
					
					echo '<script type="text/javascript"> alert("User is already exist.. try another username") </script>';
				}
			
				
					{		
						$query= "insert into user values ('$username','$password')";
						$query_run = mysqli_query($conn,$query);

						if($query_run)
						{

							echo '<script type="text/javascript"> alert("User Registered Go to login page to login") </script>';
						}
						
						else
						{
							echo '<script type="text/javascript"> alert("Error!") </script>';
						}
					}
			}
			else{
				echo '<script type="text/javascript"> alert("Password and confirm password does not match") </script>';
			}		
		}
	 ?>
	</div>
</section>

