<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home_blog extends CI_Controller {
	public function index()
	{
		$this->load->model('blog_model');
		$data['groups']=$this->blog_model->getAllGroups();
		$data['images'] = $this->blog_model->get_images();
		
		$this->load->view('templates/header');
		$this->load->view('templates/nav-blog');
		$this->load->view('blogs/Home_blog',$data);
		$this->load->view('templates/footer');
	}
	

